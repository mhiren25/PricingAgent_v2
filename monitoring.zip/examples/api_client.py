"""
Example API client for Financial Trading Agent
"""

import requests
import json
from typing import Optional, Dict, Any


class TradingAgentClient:
    """Python client for Trading Agent API"""

    def __init__(self, base_url: str = "http://localhost:8000", api_key: Optional[str] = None):
        self.base_url = base_url.rstrip('/')
        self.api_key = api_key
        self.session = requests.Session()

        if api_key:
            self.session.headers.update({"Authorization": f"Bearer {api_key}"})

    def _request(self, method: str, endpoint: str, **kwargs) -> Dict[str, Any]:
        """Make HTTP request"""
        url = f"{self.base_url}{endpoint}"
        response = self.session.request(method, url, **kwargs)
        response.raise_for_status()
        return response.json()

    def health_check(self) -> Dict[str, Any]:
        """Check API health"""
        return self._request("GET", "/health")

    def query(self, query: str, order_id: Optional[str] = None,
              date: Optional[str] = None) -> Dict[str, Any]:
        """Generic query"""
        params = {"query": query}
        if order_id:
            params["order_id"] = order_id
        if date:
            params["date"] = date

        return self._request("POST", "/api/v1/query", params=params)

    def investigate(self, order_id: str, date: Optional[str] = None,
                    reason: Optional[str] = None) -> Dict[str, Any]:
        """Investigate specific order"""
        data = {"order_id": order_id}
        if date:
            data["date"] = date
        if reason:
            data["reason"] = reason

        return self._request("POST", "/api/v1/investigate", json=data)

    def compare(self, primary_order_id: str, comparison_order_id: str,
                primary_date: Optional[str] = None,
                comparison_date: Optional[str] = None,
                reason: Optional[str] = None) -> Dict[str, Any]:
        """Compare two orders"""
        data = {
            "primary_order_id": primary_order_id,
            "comparison_order_id": comparison_order_id
        }
        if primary_date:
            data["primary_date"] = primary_date
        if comparison_date:
            data["comparison_date"] = comparison_date
        if reason:
            data["reason"] = reason

        return self._request("POST", "/api/v1/compare", json=data)

    def analyze_code(self, query: str, order_id: Optional[str] = None,
                     class_name: Optional[str] = None,
                     method_name: Optional[str] = None) -> Dict[str, Any]:
        """Analyze Java/Spring code"""
        data = {"query": query}
        if order_id:
            data["order_id"] = order_id
        if class_name:
            data["class_name"] = class_name
        if method_name:
            data["method_name"] = method_name

        return self._request("POST", "/api/v1/code/analyze", json=data)

    def get_logs(self, order_id: str, date: Optional[str] = None,
                 log_level: str = "INFO") -> Dict[str, Any]:
        """Retrieve logs"""
        data = {"order_id": order_id, "log_level": log_level}
        if date:
            data["date"] = date

        return self._request("POST", "/api/v1/logs", json=data)

    def investigate_async(self, order_id: str, date: Optional[str] = None,
                          reason: Optional[str] = None) -> Dict[str, Any]:
        """Start async investigation"""
        data = {"order_id": order_id}
        if date:
            data["date"] = date
        if reason:
            data["reason"] = reason

        return self._request("POST", "/api/v1/investigate/async", json=data)

    def get_job_status(self, job_id: str) -> Dict[str, Any]:
        """Check job status"""
        return self._request("GET", f"/api/v1/jobs/{job_id}")

    def list_agents(self) -> Dict[str, Any]:
        """List available agents"""
        return self._request("GET", "/api/v1/agents")

    def monitoring_health(self) -> Dict[str, Any]:
        """Get system monitoring health"""
        return self._request("GET", "/api/v1/monitoring/health")


# ============================================================================
# USAGE EXAMPLES
# ============================================================================

if __name__ == "__main__":
    # Initialize client
    client = TradingAgentClient("http://localhost:8000")

    # Check health
    print("=== Health Check ===")
    health = client.health_check()
    print(json.dumps(health, indent=2))

    # Example 1: Generic query
    print("\n=== Generic Query ===")
    result = client.query("How does GOLD tier pricing work?")
    print(f"Intent: {result['intent']}")
    print(f"Answer: {result['answer'][:200]}...")

    # Example 2: Investigate order
    print("\n=== Investigate Order ===")
    result = client.investigate("ABC123", date="2025-01-15", reason="Client reported incorrect price")
    print(f"Order: {result['order_id']}")
    print(f"Agents Used: {', '.join(result['agents_used'])}")
    print(f"Answer: {result['answer'][:200]}...")

    # Example 3: Compare orders
    print("\n=== Compare Orders ===")
    result = client.compare(
        "ABC123",
        "DEF456",
        primary_date="2025-01-15",
        comparison_date="2025-01-10",
        reason="Different prices for same client tier"
    )
    print(f"Primary: {result['primary_order_id']}")
    print(f"Comparison: {result['comparison_order_id']}")
    print(f"Differences: {result['differences'][:200]}...")

    # Example 4: Code analysis
    print("\n=== Code Analysis ===")
    result = client.analyze_code(
        "How does the pricing calculation work?",
        class_name="PricingService",
        method_name="calculatePrice"
    )
    print(f"Analysis: {result['answer'][:200]}...")

    # Example 5: Async investigation
    print("\n=== Async Investigation ===")
    job = client.investigate_async("XYZ789", date="2025-01-20")
    print(f"Job ID: {job['job_id']}")
    print(f"Status: {job['status']}")

    # Check job status
    import time

    time.sleep(5)  # Wait a bit
    status = client.get_job_status(job['job_id'])
    print(f"Job Status: {status['status']}")
    if status['status'] == 'completed':
        print(f"Result: {status['result']['answer'][:200]}...")

    # Example 6: List agents
    print("\n=== Available Agents ===")
    agents = client.list_agents()
    for agent in agents['agents']:
        print(f"- {agent['name']}: {agent['purpose']}")

# ============================================================================
# cURL EXAMPLES
# ============================================================================

"""
# Health Check
curl http://localhost:8000/health

# Generic Query
curl -X POST "http://localhost:8000/api/v1/query?query=How%20does%20pricing%20work"

# Investigate Order
curl -X POST http://localhost:8000/api/v1/investigate \
  -H "Content-Type: application/json" \
  -d '{
    "order_id": "ABC123",
    "date": "2025-01-15",
    "reason": "Client reported incorrect price"
  }'

# Compare Orders
curl -X POST http://localhost:8000/api/v1/compare \
  -H "Content-Type: application/json" \
  -d '{
    "primary_order_id": "ABC123",
    "comparison_order_id": "DEF456",
    "primary_date": "2025-01-15",
    "comparison_date": "2025-01-10",
    "reason": "Different prices"
  }'

# Code Analysis
curl -X POST http://localhost:8000/api/v1/code/analyze \
  -H "Content-Type: application/json" \
  -d '{
    "query": "Explain pricing calculation",
    "class_name": "PricingService",
    "method_name": "calculatePrice"
  }'

# Get Logs
curl -X POST http://localhost:8000/api/v1/logs \
  -H "Content-Type: application/json" \
  -d '{
    "order_id": "ABC123",
    "date": "2025-01-15"
  }'

# Async Investigation
curl -X POST http://localhost:8000/api/v1/investigate/async \
  -H "Content-Type: application/json" \
  -d '{
    "order_id": "ABC123",
    "date": "2025-01-15"
  }'

# Check Job Status
curl http://localhost:8000/api/v1/jobs/{job_id}

# List Agents
curl http://localhost:8000/api/v1/agents

# Monitoring Health
curl http://localhost:8000/api/v1/monitoring/health
"""