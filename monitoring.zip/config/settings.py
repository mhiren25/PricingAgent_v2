"""
Application settings and configuration management
"""

from pydantic_settings import BaseSettings, SettingsConfigDict
from typing import Optional, List
from pathlib import Path


class Settings(BaseSettings):
    """Main application settings"""

    model_config = SettingsConfigDict(
        env_file='.env',
        env_file_encoding='utf-8',
        case_sensitive=False,
        extra='ignore'
    )

    # Application
    app_env: str = "development"
    app_name: str = "financial-trading-agent"
    log_level: str = "INFO"

    # Anthropic API
    anthropic_api_key: str

    # Oracle Database
    oracle_host: str = "localhost"
    oracle_port: int = 1521
    oracle_service_name: str = "ORCL"
    oracle_username: str
    oracle_password: str
    oracle_connection_pool_size: int = 10

    # Splunk
    splunk_host: str
    splunk_port: int = 8089
    splunk_username: Optional[str] = None
    splunk_password: Optional[str] = None
    splunk_token: Optional[str] = None
    splunk_verify_ssl: bool = True

    # Debug API
    debug_api_url: str
    debug_api_token: str
    debug_api_timeout: int = 30

    # Redis
    redis_host: str = "localhost"
    redis_port: int = 6379
    redis_password: Optional[str] = None
    redis_db: int = 0
    redis_ttl_minutes: int = 5

    # Vector Database (Pinecone)
    pinecone_api_key: Optional[str] = None
    pinecone_environment: Optional[str] = None
    pinecone_index_name: Optional[str] = None

    # Prometheus/Grafana
    prometheus_url: Optional[str] = None
    grafana_url: Optional[str] = None
    grafana_api_key: Optional[str] = None

    # Git Repository
    git_repo_url: Optional[str] = None
    git_username: Optional[str] = None
    git_token: Optional[str] = None
    git_branch: str = "main"

    # Model Configuration
    supervisor_model: str = "claude-sonnet-4-5-20250929"
    agent_model: str = "claude-sonnet-4-5-20250929"
    cheap_model: str = "claude-haiku-4"
    model_temperature: float = 0.0
    model_max_tokens: int = 4096

    # Agent Configuration
    enable_reflection: bool = True
    enable_caching: bool = True
    cache_ttl_minutes: int = 5
    enable_parallel_execution: bool = False
    max_retries: int = 3
    timeout_seconds: int = 30

    # API Configuration
    api_host: str = "0.0.0.0"
    api_port: int = 8000
    api_workers: int = 4
    api_cors_origins: List[str] = ["http://localhost:3000"]

    # Authentication
    jwt_secret_key: Optional[str] = None
    jwt_algorithm: str = "HS256"
    jwt_access_token_expire_minutes: int = 30

    # Monitoring
    enable_metrics: bool = True
    metrics_port: int = 9090
    enable_tracing: bool = False
    jaeger_endpoint: Optional[str] = None

    # Feature Flags
    enable_code_agent: bool = True
    enable_comparison_agent: bool = True
    enable_async_agents: bool = False
    enable_human_in_loop: bool = False

    @property
    def oracle_dsn(self) -> str:
        """Generate Oracle DSN"""
        return f"{self.oracle_host}:{self.oracle_port}/{self.oracle_service_name}"

    @property
    def redis_url(self) -> str:
        """Generate Redis URL"""
        if self.redis_password:
            return f"redis://:{self.redis_password}@{self.redis_host}:{self.redis_port}/{self.redis_db}"
        return f"redis://{self.redis_host}:{self.redis_port}/{self.redis_db}"

    @property
    def is_production(self) -> bool:
        """Check if running in production"""
        return self.app_env.lower() == "production"

    @property
    def is_development(self) -> bool:
        """Check if running in development"""
        return self.app_env.lower() == "development"


# Singleton instance
_settings: Optional[Settings] = None


def get_settings() -> Settings:
    """Get settings singleton"""
    global _settings
    if _settings is None:
        _settings = Settings()
    return _settings


# For convenience
settings = get_settings()