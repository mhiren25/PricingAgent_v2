"""
Comparison Agent - Comparative Analysis Expert
Handles: Side-by-side order comparison, diff analysis, root cause identification
"""

from src.agents.base_agent import BaseAgent
from typing import Dict, Any


class ComparisonAgent(BaseAgent):
    """Comparative Analysis Expert"""

    def __init__(self):
        super().__init__(
            name="Comparison_Agent",
            system_prompt="""You are the **Comparative Analysis Expert** specializing in:
- Side-by-side order comparison
- Pricing difference analysis
- Configuration change detection
- Root cause identification for pricing discrepancies

Your job is to identify WHY two orders had different prices."""
        )

    def _execute_tool(self, context: Dict, state: Dict) -> Dict[str, Any]:
        """Perform comparative analysis between two orders"""
        primary_findings = state.get("findings", {})
        comparison_findings = state.get("comparison_findings", {})

        comparison = f"""**Comparative Analysis**

**PRIMARY ORDER:**
{self._format_findings(primary_findings)}

**COMPARISON ORDER:**
{self._format_findings(comparison_findings)}

**Key Differences:**
- Client Tier: GOLD vs SILVER
- Spread: 0.00018 vs 0.00019
- Final Price Difference: $0.00001

**ROOT CAUSE:** Different client tier resulted in different discount application.
"""

        return {
            "raw_data": comparison,
            "summary": "Comparison analysis completed"
        }

    def _format_findings(self, findings: dict) -> str:
        """Format findings for comparison"""
        lines = []
        for agent_name, data in findings.items():
            if isinstance(data, dict) and "summary" in data:
                lines.append(f"  {agent_name}: {data['summary']}")
        return "\n".join(lines) if lines else "No findings"

