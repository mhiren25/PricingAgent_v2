"""
Splunk Agent - Log Analysis & Forensics Expert
Handles: Log retrieval, order tracking, error analysis
"""

from src.agents.base_agent import BaseAgent
from langchain_core.tools import tool
from typing import Dict, Any


class SplunkAgent(BaseAgent):
    """
    Log Analysis & Forensics Expert

    Responsibilities:
    - Search Splunk logs for order processing
    - Analyze XML messages
    - Track order flow through system
    - Identify errors and anomalies
    """

    def __init__(self):
        super().__init__(
            name="Splunk_Agent",
            system_prompt="""You are the **Log Analysis Expert** specializing in:
- Splunk log queries and analysis
- Order processing flow tracking
- Error pattern detection
- XML message parsing and interpretation

Analyze logs thoroughly and identify root causes of issues."""
        )

    @tool
    def search_logs(self, order_id: str, date: str) -> str:
        """
        Search Splunk for order processing logs.

        Args:
            order_id: Order identifier
            date: Date in YYYY-MM-DD format

        Returns:
            Log entries and analysis
        """
        # TODO: Replace with actual Splunk API
        return f"""**Splunk Query Results**
index=trading sourcetype=pricing order_id={order_id} date={date}

📋 **Log Entries Found: 15**

**Key Events:**
1. [2025-01-15 10:23:45] Order received - Order ID: {order_id}
2. [2025-01-15 10:23:46] Pricing calculation initiated
3. [2025-01-15 10:23:47] Client tier: GOLD, Instrument: EURUSD
4. [2025-01-15 10:23:48] Base price: 1.0850, Spread: 0.0002
5. [2025-01-15 10:23:49] Final price calculated: 1.0852

**XML Request:**
<PricingRequest>
  <OrderId>{order_id}</OrderId>
  <Client>ABC_Corp</Client>
  <Instrument>EURUSD</Instrument>
  <Quantity>1000000</Quantity>
</PricingRequest>

**XML Response:**
<PricingResponse>
  <FinalPrice>1.0852</FinalPrice>
  <Timestamp>2025-01-15T10:23:49Z</Timestamp>
  <Status>SUCCESS</Status>
</PricingResponse>

**Status:** ✅ Order processed successfully
"""

    def _execute_tool(self, context: Dict, state: Dict) -> Dict[str, Any]:
        """
        Execute log search and analysis

        Args:
            context: Investigation context
            state: Current agent state

        Returns:
            Dict with log search results
        """
        order_id = context.get("order_id", "")
        date = context.get("date", "")
        prefix = context.get("prefix", "")

        # Validate required parameters
        if not order_id or not date:
            return {
                "error": "Missing order_id or date",
                "summary": f"{prefix} ⚠️ Order ID and date required for log search"
            }

        # Search logs
        logs = self.search_logs.invoke({"order_id": order_id, "date": date})

        return {
            "raw_data": logs,
            "summary": f"Logs retrieved for {order_id}",
            "order_id": order_id
        }