"""
VectorDB Agent - Knowledge Base & Documentation Retrieval Expert
Handles: Documentation queries, how-to questions, knowledge retrieval
"""

from src.agents.base_agent import BaseAgent
from langchain_core.tools import tool
from typing import Dict, Any


class VectorDBAgent(BaseAgent):
    """
    Knowledge Base & Documentation Expert

    Responsibilities:
    - Search knowledge base for pricing documentation
    - Retrieve configuration guidelines
    - Answer "how does it work" questions
    - Provide troubleshooting guides

    Uses: Cheaper model (Haiku) for cost optimization
    """

    def __init__(self):
        super().__init__(
            name="VectorDB_Agent",
            system_prompt="""You are the **Knowledge Base Expert** specializing in:
- Financial trading documentation
- Client pricing rules and configurations
- System architecture and design documents
- Best practices and troubleshooting guides

Your role is to search the vector database and provide relevant documentation.
Always cite sources and provide actionable information.""",
            use_cheap_model=True  # Knowledge retrieval uses cheaper model
        )

    @tool
    def search_knowledge_base(self, query: str) -> str:
        """
        Search vector database for documentation and knowledge.

        Args:
            query: Search query for knowledge retrieval

        Returns:
            Relevant documentation results
        """
        # TODO: Replace with actual vector DB implementation (Pinecone, Weaviate, etc.)
        return f"""**Knowledge Base Results for: {query}**

📚 **Relevant Documentation:**
1. Client Pricing Overview:
   - Pricing is calculated based on client tier, instrument type, and market conditions
   - Configuration stored in PRICING_CONFIG table
   - Real-time adjustments via pricing engine

2. Troubleshooting Guide:
   - Check PRICING_RULES table for client-specific overrides
   - Verify pricing engine status in monitoring dashboard
   - Common issues: stale cache, incorrect tier mapping

**Source:** Internal Wiki - Client Pricing v2.3 (Updated: Jan 2025)
"""

    def _execute_tool(self, context: Dict, state: Dict) -> Dict[str, Any]:
        """
        Execute knowledge retrieval

        Args:
            context: Investigation context
            state: Current agent state

        Returns:
            Dict with knowledge search results
        """
        query = state.get("user_query", "")

        # Search knowledge base
        result = self.search_knowledge_base.invoke({"query": query})

        return {
            "raw_data": result,
            "summary": "Knowledge retrieved successfully"
        }