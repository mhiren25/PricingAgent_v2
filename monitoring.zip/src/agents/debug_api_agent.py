"""
DebugAPI Agent - Simulation & Testing Expert
Handles: Order simulation, pricing validation, what-if analysis
"""

from src.agents.base_agent import BaseAgent
from langchain_core.tools import tool
from typing import Dict, Any


class DebugAPIAgent(BaseAgent):
    """Simulation & Testing Expert"""

    def __init__(self):
        super().__init__(
            name="DebugAPI_Agent",
            system_prompt="""You are the **Simulation Expert** specializing in:
- Debug API interaction
- Order simulation and testing
- Pricing calculation validation
- What-if scenario analysis

Run simulations to reproduce issues or test configurations."""
        )

    @tool
    def simulate_order(self, params: str) -> str:
        """Simulate order processing via Debug API."""
        # TODO: Replace with actual Debug API call
        return f"""**Debug API Simulation**

**Input Parameters:**
{params}

**Simulation Results:**
```xml
<SimulationResponse>
  <Request>
    <Client>ABC_Corp</Client>
    <Instrument>EURUSD</Instrument>
    <Quantity>1000000</Quantity>
    <ClientTier>GOLD</ClientTier>
  </Request>

  <Calculation>
    <BasePrice>1.0850</BasePrice>
    <StandardSpread>0.0002</StandardSpread>
    <TierDiscount>-10%</TierDiscount>
    <AdjustedSpread>0.00018</AdjustedSpread>
    <FinalPrice>1.08518</FinalPrice>
  </Calculation>

  <Metadata>
    <SimulationTime>45ms</SimulationTime>
    <PricingEngine>v3.2.1</PricingEngine>
    <Status>SUCCESS</Status>
  </Metadata>
</SimulationResponse>
```

**Validation:** ✅ Calculation matches expected pricing logic
**Performance:** ⚡ 45ms response time (within SLA)
"""

    def _execute_tool(self, context: Dict, state: Dict) -> Dict[str, Any]:
        """Execute order simulation"""
        findings_key = context["findings_key"]
        db_findings = state.get(findings_key, {}).get("Database_Agent", {})
        params = db_findings.get("raw_data", state.get("user_query", ""))

        result = self.simulate_order.invoke({"params": params})

        return {
            "raw_data": result,
            "summary": "Simulation completed successfully"
        }

