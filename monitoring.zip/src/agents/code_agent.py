"""
Code Agent - Java Code Analysis Expert
Handles: Java/Spring analysis, execution tracing, configuration review
"""

from src.agents.base_agent import BaseAgent
from langchain_core.tools import tool
from typing import Dict, Any


class CodeAgent(BaseAgent):
    """Java Code Analysis Expert"""

    def __init__(self):
        super().__init__(
            name="Code_Agent",
            system_prompt="""You are the **Code Analysis Expert** specializing in:
- Java 11 application code analysis
- Spring Framework (Spring Boot, Spring MVC, Spring DI)
- Dependency Injection patterns
- Property management
- SOAP/REST endpoints
- Microservices architecture

Explain code clearly and identify issues accurately."""
        )

    @tool
    def analyze_code(self, query: str) -> str:
        """Analyze Java code implementation."""
        # TODO: Replace with actual code repository integration
        return f"""**Code Analysis Results**

**Query:** {query}

**Source Code Located:**
```java
// PricingService.java
@Service
public class PricingService {{

    @Autowired
    private PricingRepository pricingRepository;

    @Value("${{pricing.spread.default}}")
    private Double defaultSpread;

    public PricingResponse calculatePrice(OrderRequest order) {{
        Double basePrice = getBasePrice(order.getInstrument());
        ClientConfig config = getClientConfig(order.getClientId());
        Double spread = applyTierDiscount(defaultSpread, config.getTier());
        return new PricingResponse(basePrice + spread);
    }}
}}
```

**Key Findings:**
✅ Standard Spring DI patterns used correctly
✅ Properties externalized in application.yml
⚠️  No null checking on getBasePrice()
⚠️  Volume discount hardcoded (should be configurable)
"""

    def _execute_tool(self, context: Dict, state: Dict) -> Dict[str, Any]:
        """Execute code analysis"""
        query = state.get("user_query", "")

        result = self.analyze_code.invoke({"query": query})

        return {
            "raw_data": result,
            "summary": "Code analysis completed"
        }

