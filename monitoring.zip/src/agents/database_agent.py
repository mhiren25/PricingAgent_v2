"""
Database Agent - Oracle Database & Configuration Expert
Handles: SQL queries, configuration lookup, trade data retrieval
"""

from src.agents.base_agent import BaseAgent
from langchain_core.tools import tool
from typing import Dict, Any


class DatabaseAgent(BaseAgent):
    """Oracle Database & Configuration Expert"""

    def __init__(self):
        super().__init__(
            name="Database_Agent",
            system_prompt="""You are the **Database Expert** specializing in:
- Oracle SQL queries and optimization
- Trade data retrieval
- Configuration lookup (pricing rules, client tiers)
- Data integrity validation

Provide precise SQL queries and interpret database results accurately."""
        )

    @tool
    def query_database(self, order_id: str) -> str:
        """Query Oracle database for order details."""
        # TODO: Replace with actual Oracle connection
        return f"""**Database Query Results**

```sql
SELECT o.order_id, o.client_id, c.tier, o.instrument, 
       o.quantity, o.status, p.base_price, p.spread
FROM orders o
JOIN clients c ON o.client_id = c.client_id
JOIN pricing p ON o.instrument = p.instrument
WHERE o.order_id = '{order_id}';
```

**Results:**
| ORDER_ID | CLIENT_ID | TIER | INSTRUMENT | QUANTITY | STATUS | BASE_PRICE | SPREAD |
|----------|-----------|------|------------|----------|--------|------------|--------|
| {order_id} | CLI_001 | GOLD | EURUSD | 1000000 | COMPLETED | 1.0850 | 0.0002 |

**Client Configuration:**
- Client: ABC Corporation (CLI_001)
- Tier: GOLD (10% discount on spreads)
- Active Since: 2020-03-15
- Credit Limit: $50M

**Pricing Rules Applied:**
- Base pricing: Market rate
- Spread adjustment: -10% (GOLD tier)
- Volume discount: Applied for trades > 500K
"""

    def _execute_tool(self, context: Dict, state: Dict) -> Dict[str, Any]:
        """Execute database queries"""
        order_id = context.get("order_id", "")

        if not order_id:
            return {
                "error": "Missing order_id",
                "summary": "⚠️ Order ID required for database lookup"
            }

        result = self.query_database.invoke({"order_id": order_id})

        return {
            "raw_data": result,
            "summary": f"Database records retrieved for {order_id}",
            "order_id": order_id
        }