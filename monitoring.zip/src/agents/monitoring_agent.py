"""
Monitoring Agent - System Monitoring & Metrics Expert
Handles: Prometheus queries, system health, performance metrics
"""

from src.agents.base_agent import BaseAgent
from langchain_core.tools import tool
from typing import Dict, Any


class MonitoringAgent(BaseAgent):
    """System Monitoring & Metrics Expert"""

    def __init__(self):
        super().__init__(
            name="Monitoring_Agent",
            system_prompt="""You are the **Monitoring Expert** specializing in:
- Prometheus metrics analysis
- Grafana dashboard interpretation
- System health assessment
- Performance trend analysis

Provide insights into system behavior and potential issues.""",
            use_cheap_model=True  # Monitoring uses cheaper model
        )

    @tool
    def get_metrics(self, query: str) -> str:
        """Query Prometheus/Grafana for metrics."""
        # TODO: Replace with actual Prometheus API
        return f"""**System Metrics Dashboard**

📊 **Pricing Service Health (Last 1 hour):**
- CPU Usage: 45% (avg), 78% (peak)
- Memory: 3.2GB / 8GB (40%)
- Request Rate: 1,250 req/min
- Error Rate: 0.8% (10 errors/1250 requests)
- Latency: p50=85ms, p95=220ms, p99=450ms

📈 **Trends:**
- ✅ CPU stable, no spikes
- ⚠️  3 latency spikes detected at 10:15, 10:42, 11:03
- ✅ Error rate within acceptable range (<1%)
- 📉 Cache hit rate: 92% (good)

🔍 **Recent Alerts:**
1. [10:15] Latency spike (p99: 850ms) - Duration: 2min - RESOLVED
2. [10:42] Database connection pool exhaustion - Duration: 30sec - RESOLVED

**System Status:** 🟢 HEALTHY (Minor performance fluctuations)
"""

    def _execute_tool(self, context: Dict, state: Dict) -> Dict[str, Any]:
        """Execute metrics retrieval and analysis"""
        query = state.get("user_query", "pricing service")

        result = self.get_metrics.invoke({"query": query})

        return {
            "raw_data": result,
            "summary": "System metrics retrieved"
        }
