"""
Supervisor Agent - Orchestrator
Handles: Query analysis, agent routing, findings synthesis
"""

from src.agents.base_agent import BaseAgent
from src.agents.vector_db_agent import VectorDBAgent
from src.agents.splunk_agent import SplunkAgent
from src.agents.database_agent import DatabaseAgent
from src.agents.debug_api_agent import DebugAPIAgent
from src.agents.monitoring_agent import MonitoringAgent
from src.agents.code_agent import CodeAgent
from src.agents.comparison_agent import ComparisonAgent
from src.models.query_parameters import QueryParameters
from langchain_anthropic import ChatAnthropic
from langchain_core.messages import SystemMessage, HumanMessage, AIMessage
from typing import Dict, Any
from config.settings import settings


class SupervisorAgent:
    """Orchestrates specialist agents and synthesizes findings"""

    def __init__(self):
        self.name = "Supervisor"
        self.llm = ChatAnthropic(
            model=settings.supervisor_model,
            temperature=0
        ).with_structured_output(QueryParameters)

        # Initialize all specialist agents
        self.agents = {
            "VectorDB_Agent": VectorDBAgent(),
            "Splunk_Agent": SplunkAgent(),
            "Database_Agent": DatabaseAgent(),
            "DebugAPI_Agent": DebugAPIAgent(),
            "Monitoring_Agent": MonitoringAgent(),
            "Code_Agent": CodeAgent(),
            "Comparison_Agent": ComparisonAgent()
        }

    def analyze_query(self, state: Dict) -> Dict:
        """Analyze query with structured output - extract parameters and intent"""

        analysis_prompt = f"""Analyze this financial trading query:

**User Query:** {state['user_query']}

Extract:
- Intent (Knowledge/Data/Debug/Investigation/Monitoring/CodeAnalysis/Comparison)
- Order IDs and dates
- Brief reasoning

Provide structured output."""

        try:
            params: QueryParameters = self.llm.invoke(analysis_prompt)
            state["parameters"] = params

            state["messages"].append(AIMessage(
                content=f"""**[Supervisor Analysis]**
Intent: {params.intent}
Order ID: {params.order_id or 'N/A'}
Reasoning: {params.reasoning}""",
                name=self.name
            ))
        except Exception as e:
            # Fallback
            state["parameters"] = QueryParameters(intent="Investigation")

        return state

    def synthesize_findings(self, state: Dict) -> Dict:
        """Synthesize final answer from all agent findings"""
        params = state.get("parameters")
        findings_summary = self._format_findings(state)

        synthesis_prompt = f"""Synthesize findings:

**Query:** {state['user_query']}
**Findings:** {findings_summary}

Provide clear, professional answer with key insights."""

        llm = ChatAnthropic(model=settings.supervisor_model, temperature=0)
        response = llm.invoke(synthesis_prompt)

        state["final_answer"] = response.content
        state["messages"].append(AIMessage(
            content=f"\n{'=' * 80}\n**FINAL ANSWER**\n{'=' * 80}\n\n{response.content}",
            name=self.name
        ))

        return state

    def _format_findings(self, state: Dict) -> str:
        """Format all findings for synthesis"""
        lines = []
        for agent_name, findings in state.get("findings", {}).items():
            if isinstance(findings, dict):
                summary = findings.get("summary", findings.get("analysis", ""))
                lines.append(f"**{agent_name}:** {summary}")
        return "\n\n".join(lines) if lines else "No findings"

