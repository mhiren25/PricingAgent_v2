class BaseAgent(ABC):
    """Base class with common functionality for all agents"""

    def __init__(self, name: str, system_prompt: str, use_cheap_model: bool = False):
        self.name = name
        self.system_prompt = system_prompt
        model = MODEL_CONFIG.cheap_model if use_cheap_model else MODEL_CONFIG.agent_model
        self.llm = ChatAnthropic(
            model=model,
            temperature=MODEL_CONFIG.temperature,
            max_tokens=MODEL_CONFIG.max_tokens
        )

    def _get_investigation_context(self, state: AgentState) -> dict:
        """Extract investigation context (primary or comparison)"""
        current_inv = state.get("current_investigation", "primary")
        params = state.get("parameters")

        if current_inv == "comparison":
            return {
                "order_id": params.comparison_order_id if params else "",
                "date": params.comparison_date if params else "",
                "findings_key": "comparison_findings",
                "prefix": "[COMPARISON ORDER]"
            }
        return {
            "order_id": params.order_id if params else "",
            "date": params.date if params else "",
            "findings_key": "findings",
            "prefix": "[PRIMARY ORDER]"
        }

    def _get_cache_key(self, *args) -> str:
        """Generate cache key"""
        cache_str = f"{self.name}_{'_'.join(str(a) for a in args)}"
        return hashlib.md5(cache_str.encode()).hexdigest()

    def _store_findings(self, state: AgentState, findings: dict, context: dict):
        """Store findings in appropriate state location"""
        findings_key = context["findings_key"]
        if findings_key not in state:
            state[findings_key] = {}

        # Store only essential data to prevent state bloat
        state[findings_key][self.name] = {
            "summary": findings.get("summary", ""),
            "analysis": findings.get("analysis", ""),
            "order_id": context.get("order_id"),
            "timestamp": datetime.now().isoformat(),
            # Large data stored in cache
            "cache_key": findings.get("cache_key")
        }

    @abstractmethod
    def _execute_tool(self, context: dict, state: AgentState) -> dict:
        """Execute the agent's main tool - implemented by subclasses"""
        pass

    def _needs_reflection(self, tool_output: str) -> bool:
        """Determine if LLM reflection is needed (optimization)"""
        # Simple heuristic: skip reflection for successful, straightforward results
        if "error" in tool_output.lower():
            return True
        if len(tool_output) > 5000:  # Complex output needs analysis
            return True
        if AGENT_CONFIG.enable_reflection:
            return True
        return False

    @retry(
        stop=stop_after_attempt(AGENT_CONFIG.max_retries),
        wait=wait_exponential(multiplier=1, min=2, max=10),
        retry=retry_if_exception_type((ConnectionError, TimeoutError))
    )
    def execute(self, state: AgentState) -> AgentState:
        """Main execution with error handling and retry logic"""
        context = self._get_investigation_context(state)
        prefix = context["prefix"]

        try:
            # Check cache first
            if AGENT_CONFIG.use_caching:
                cache_key = self._get_cache_key(
                    context["order_id"],
                    context.get("date", "")
                )
                cached = CACHE.get(cache_key, AGENT_CONFIG.cache_ttl_minutes)
                if cached:
                    logger.info(f"{self.name}: Using cached result")
                    findings = cached
                else:
                    findings = self._execute_tool(context, state)
                    CACHE.set(cache_key, findings)
            else:
                findings = self._execute_tool(context, state)

            # Reflection (optional, based on need)
            if self._needs_reflection(str(findings)):
                analysis = self._reflect(findings, context, state)
            else:
                analysis = self._simple_summary(findings)

            # Store findings efficiently
            findings["analysis"] = analysis
            self._store_findings(state, findings, context)

            # Add message
            state["messages"].append(AIMessage(
                content=f"**[{self.name}] {prefix}**\n\n{analysis}",
                name=self.name
            ))

        except Exception as e:
            logger.error(f"{self.name} failed: {str(e)}")
            error_msg = f"⚠️ {self.name} encountered an error: {str(e)}"

            state["error_log"].append(f"{self.name}: {str(e)}")
            state["messages"].append(AIMessage(
                content=f"**[{self.name}] {prefix}**\n\n{error_msg}",
                name=self.name
            ))

            # Store error in findings
            self._store_findings(state, {"error": str(e)}, context)

        return state

    def _reflect(self, findings: dict, context: dict, state: AgentState) -> str:
        """LLM-based reflection on findings"""
        reflection_prompt = f"""
<Show Your Thinking>
Tool Output: {findings.get('raw_data', findings)}

User Query: {state.get('user_query', '')}
Context: {context.get('prefix', '')}

Analysis:
1. What key information was found?
2. How does this relate to the user's query?
3. Are there any issues or anomalies?
4. What are the key takeaways?
</Show Your Thinking>

Provide a concise, actionable summary (3-5 sentences max).
"""

        messages = [
            SystemMessage(content=self.system_prompt),
            HumanMessage(content=reflection_prompt)
        ]

        response = self.llm.invoke(messages)
        return response.content

    def _simple_summary(self, findings: dict) -> str:
        """Simple summary without LLM (faster, cheaper)"""
        return findings.get("summary", str(findings)[:500])
