"""Agent state definition"""
from typing import TypedDict, Annotated, Sequence, Any
from langchain_core.messages import BaseMessage
import operator


class AgentState(TypedDict):
    """Shared state across all agents"""
    messages: Annotated[Sequence[BaseMessage], operator.add]
    user_query: str
    parameters: Any
    investigation_step: int
    findings: dict
    comparison_findings: dict
    final_answer: str
    sender: str
    current_investigation: str
    error_log: list
