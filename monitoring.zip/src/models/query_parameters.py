"""Query parameters model"""
from pydantic import BaseModel, Field
from typing import Literal, List


class QueryParameters(BaseModel):
    """Structured parameters from query"""
    intent: Literal["Knowledge", "Data", "Debug", "Investigation",
    "Monitoring", "CodeAnalysis", "Comparison"]
    order_id: str = ""
    comparison_order_id: str = ""
    date: str = ""
    comparison_date: str = ""
    agents_needed: List[str] = []
    reasoning: str = ""
