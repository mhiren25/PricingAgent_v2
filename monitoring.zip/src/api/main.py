"""
FastAPI application for Financial Trading Agent
"""

from fastapi import FastAPI, HTTPException, Depends, BackgroundTasks, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, StreamingResponse
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from contextlib import asynccontextmanager
import uvicorn
import logging
from datetime import datetime
from typing import Optional, List
import asyncio
import json

from src.api.routes import router
from src.api.middleware import (
    RequestLoggingMiddleware,
    RateLimitMiddleware,
    MetricsMiddleware
)
from src.graph.workflow import create_supervisor_graph
from config.settings import settings

# Setup logging
logging.basicConfig(
    level=getattr(logging, settings.log_level),
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Global agent instance
agent_graph = None


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan management"""
    global agent_graph

    # Startup
    logger.info("🚀 Starting Financial Trading Agent API")
    logger.info(f"Environment: {settings.app_env}")
    logger.info(f"Model: {settings.supervisor_model}")

    # Initialize agent graph
    logger.info("Initializing agent graph...")
    agent_graph = create_supervisor_graph()
    logger.info("✓ Agent graph initialized")

    # Warm up (optional)
    if settings.is_production:
        logger.info("Warming up agent...")
        # Could run a test query here

    yield

    # Shutdown
    logger.info("Shutting down agent API")
    agent_graph = None


# Create FastAPI app
app = FastAPI(
    title="Financial Trading Data & Debugging Agent API",
    description="Multi-agent system for investigating client pricing issues",
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc",
    lifespan=lifespan
)

# CORS configuration
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.api_cors_origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Custom middleware
app.add_middleware(RequestLoggingMiddleware)
app.add_middleware(RateLimitMiddleware, max_requests=100, window_seconds=60)
app.add_middleware(MetricsMiddleware)

# Include routes
app.include_router(router, prefix="/api/v1")


# ============================================================================
# HEALTH & STATUS ENDPOINTS
# ============================================================================

@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {
        "status": "healthy",
        "timestamp": datetime.now().isoformat(),
        "environment": settings.app_env,
        "agent_initialized": agent_graph is not None
    }


@app.get("/")
async def root():
    """Root endpoint with API information"""
    return {
        "service": "Financial Trading Agent API",
        "version": "1.0.0",
        "status": "operational",
        "documentation": "/docs",
        "health": "/health",
        "endpoints": {
            "investigate": "POST /api/v1/investigate",
            "compare": "POST /api/v1/compare",
            "code_analysis": "POST /api/v1/code/analyze",
            "logs": "POST /api/v1/logs",
            "monitoring": "GET /api/v1/monitoring/health"
        }
    }


@app.get("/status")
async def status():
    """Detailed status endpoint"""
    return {
        "api": {
            "status": "healthy",
            "uptime_seconds": 0,  # TODO: Track actual uptime
            "version": "1.0.0"
        },
        "agent": {
            "initialized": agent_graph is not None,
            "supervisor_model": settings.supervisor_model,
            "agent_model": settings.agent_model
        },
        "configuration": {
            "caching_enabled": settings.enable_caching,
            "reflection_enabled": settings.enable_reflection,
            "max_retries": settings.max_retries,
            "timeout_seconds": settings.timeout_seconds
        },
        "features": {
            "code_agent": settings.enable_code_agent,
            "comparison_agent": settings.enable_comparison_agent,
            "async_agents": settings.enable_async_agents
        }
    }


# ============================================================================
# ERROR HANDLERS
# ============================================================================

@app.exception_handler(HTTPException)
async def http_exception_handler(request: Request, exc: HTTPException):
    """Handle HTTP exceptions"""
    return JSONResponse(
        status_code=exc.status_code,
        content={
            "error": exc.detail,
            "status_code": exc.status_code,
            "timestamp": datetime.now().isoformat()
        }
    )


@app.exception_handler(Exception)
async def general_exception_handler(request: Request, exc: Exception):
    """Handle general exceptions"""
    logger.error(f"Unhandled exception: {exc}", exc_info=True)
    return JSONResponse(
        status_code=500,
        content={
            "error": "Internal server error",
            "message": str(exc) if settings.is_development else "An error occurred",
            "status_code": 500,
            "timestamp": datetime.now().isoformat()
        }
    )


# ============================================================================
# DEPENDENCY INJECTION
# ============================================================================

def get_agent_graph():
    """Get agent graph dependency"""
    if agent_graph is None:
        raise HTTPException(
            status_code=503,
            detail="Agent not initialized. Service is starting up."
        )
    return agent_graph


# ============================================================================
# MAIN
# ============================================================================

def run_server():
    """Run the FastAPI server"""
    uvicorn.run(
        "src.api.main:app",
        host=settings.api_host,
        port=settings.api_port,
        workers=settings.api_workers if settings.is_production else 1,
        reload=settings.is_development,
        log_level=settings.log_level.lower()
    )


if __name__ == "__main__":
    run_server()