"""
Pydantic schemas for API requests and responses
"""

from pydantic import BaseModel, Field
from typing import Optional, List, Dict, Any
from datetime import datetime


# ============================================================================
# REQUEST SCHEMAS
# ============================================================================

class InvestigateRequest(BaseModel):
    """Request to investigate a single order"""
    order_id: str = Field(..., description="Order ID to investigate")
    date: Optional[str] = Field(None, description="Date in YYYY-MM-DD format")
    reason: Optional[str] = Field(None, description="Reason for investigation")

    class Config:
        json_schema_extra = {
            "example": {
                "order_id": "ABC123",
                "date": "2025-01-15",
                "reason": "Incorrect pricing reported by client"
            }
        }


class CompareRequest(BaseModel):
    """Request to compare two orders"""
    primary_order_id: str = Field(..., description="Primary order ID")
    comparison_order_id: str = Field(..., description="Order ID to compare against")
    primary_date: Optional[str] = Field(None, description="Primary order date")
    comparison_date: Optional[str] = Field(None, description="Comparison order date")
    reason: Optional[str] = Field(None, description="Reason for comparison")

    class Config:
        json_schema_extra = {
            "example": {
                "primary_order_id": "ABC123",
                "comparison_order_id": "DEF456",
                "primary_date": "2025-01-15",
                "comparison_date": "2025-01-10",
                "reason": "Why different prices for same client tier?"
            }
        }


class CodeAnalysisRequest(BaseModel):
    """Request for code analysis"""
    query: str = Field(..., description="Code analysis query")
    order_id: Optional[str] = Field(None, description="Order ID for context")
    class_name: Optional[str] = Field(None, description="Specific class to analyze")
    method_name: Optional[str] = Field(None, description="Specific method to analyze")

    class Config:
        json_schema_extra = {
            "example": {
                "query": "How does the pricing calculation work?",
                "order_id": "ABC123",
                "class_name": "PricingService",
                "method_name": "calculatePrice"
            }
        }


class LogsRequest(BaseModel):
    """Request to retrieve logs"""
    order_id: str = Field(..., description="Order ID")
    date: Optional[str] = Field(None, description="Date in YYYY-MM-DD format")
    log_level: Optional[str] = Field("INFO", description="Minimum log level")

    class Config:
        json_schema_extra = {
            "example": {
                "order_id": "ABC123",
                "date": "2025-01-15",
                "log_level": "INFO"
            }
        }


# ============================================================================
# RESPONSE SCHEMAS
# ============================================================================

class BaseResponse(BaseModel):
    """Base response schema"""
    success: bool
    answer: str
    intent: str
    agents_used: List[str]
    total_messages: int
    errors: List[str]
    timestamp: str


class QueryResponse(BaseResponse):
    """Response for generic query"""
    query: str
    order_id: Optional[str] = None

    class Config:
        json_schema_extra = {
            "example": {
                "success": True,
                "query": "How does GOLD tier pricing work?",
                "answer": "GOLD tier clients receive a 10% discount on spreads...",
                "intent": "Knowledge",
                "agents_used": ["VectorDB_Agent"],
                "total_messages": 2,
                "errors": [],
                "timestamp": "2025-01-15T10:30:00Z"
            }
        }


class InvestigateResponse(BaseResponse):
    """Response for investigation"""
    order_id: str
    date: Optional[str]
    findings: Optional[Dict[str, Any]] = None

    class Config:
        json_schema_extra = {
            "example": {
                "success": True,
                "order_id": "ABC123",
                "date": "2025-01-15",
                "answer": "Investigation complete. Order processed successfully with final price 1.0852...",
                "intent": "Investigation",
                "agents_used": ["Splunk_Agent", "Database_Agent", "DebugAPI_Agent"],
                "total_messages": 6,
                "errors": [],
                "findings": {
                    "primary": {
                        "Splunk_Agent": {"summary": "Logs retrieved"},
                        "Database_Agent": {"summary": "Config loaded"},
                        "DebugAPI_Agent": {"summary": "Simulation complete"}
                    }
                },
                "timestamp": "2025-01-15T10:30:00Z"
            }
        }


class CompareResponse(BaseResponse):
    """Response for comparison"""
    primary_order_id: str
    comparison_order_id: str
    differences: str
    findings: Optional[Dict[str, Any]] = None

    class Config:
        json_schema_extra = {
            "example": {
                "success": True,
                "primary_order_id": "ABC123",
                "comparison_order_id": "DEF456",
                "differences": "Key difference: Client tier (GOLD vs SILVER) resulted in different discount...",
                "answer": "Comparison complete. Root cause identified...",
                "intent": "Comparison",
                "agents_used": ["Splunk_Agent", "Database_Agent", "DebugAPI_Agent", "Comparison_Agent"],
                "total_messages": 12,
                "errors": [],
                "timestamp": "2025-01-15T10:30:00Z"
            }
        }


class CodeAnalysisResponse(BaseResponse):
    """Response for code analysis"""
    query: str
    code_snippet: Optional[str] = None

    class Config:
        json_schema_extra = {
            "example": {
                "success": True,
                "query": "Explain pricing calculation",
                "answer": "The PricingService.calculatePrice() method performs the following steps...",
                "code_snippet": "public PricingResponse calculatePrice(OrderRequest order) {...}",
                "intent": "CodeAnalysis",
                "agents_used": ["Code_Agent"],
                "total_messages": 2,
                "errors": [],
                "timestamp": "2025-01-15T10:30:00Z"
            }
        }


class LogsResponse(BaseResponse):
    """Response for logs retrieval"""
    order_id: str
    date: Optional[str]
    log_entries: Optional[List[Dict[str, Any]]] = None

    class Config:
        json_schema_extra = {
            "example": {
                "success": True,
                "order_id": "ABC123",
                "date": "2025-01-15",
                "answer": "15 log entries found for order ABC123...",
                "intent": "Data",
                "agents_used": ["Splunk_Agent"],
                "total_messages": 2,
                "errors": [],
                "timestamp": "2025-01-15T10:30:00Z"
            }
        }


# ============================================================================
# JOB STATUS SCHEMAS
# ============================================================================

class JobStatus(BaseModel):
    """Background job status"""
    job_id: str
    status: str  # pending, running, completed, failed
    created_at: str
    started_at: Optional[str] = None
    completed_at: Optional[str] = None
    result: Optional[Dict[str, Any]] = None
    error: Optional[str] = None

    class Config:
        json_schema_extra = {
            "example": {
                "job_id": "123e4567-e89b-12d3-a456-426614174000",
                "status": "completed",
                "created_at": "2025-01-15T10:30:00Z",
                "started_at": "2025-01-15T10:30:01Z",
                "completed_at": "2025-01-15T10:30:15Z",
                "result": {"answer": "Investigation complete..."},
                "error": None
            }
        }


# ============================================================================
# STREAMING SCHEMAS
# ============================================================================

class StreamResponse(BaseModel):
    """Streaming response chunk"""
    type: str  # start, agent_message, complete, error
    agent: Optional[str] = None
    content: Optional[str] = None
    timestamp: Optional[str] = None

    class Config:
        json_schema_extra = {
            "example": {
                "type": "agent_message",
                "agent": "Splunk_Agent",
                "content": "Logs retrieved for order ABC123...",
                "timestamp": "2025-01-15T10:30:05Z"
            }
        }


# ============================================================================
# ERROR SCHEMAS
# ============================================================================

class ErrorResponse(BaseModel):
    """Error response"""
    error: str
    detail: Optional[str] = None
    status_code: int
    timestamp: str

    class Config:
        json_schema_extra = {
            "example": {
                "error": "Order not found",
                "detail": "Order ABC123 does not exist in the system",
                "status_code": 404,
                "timestamp": "2025-01-15T10:30:00Z"
            }
        }